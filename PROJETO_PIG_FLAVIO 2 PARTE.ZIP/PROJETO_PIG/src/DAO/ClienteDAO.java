/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Modelo.Cidade;
import Modelo.Cliente;
import Modelo.Estado;
import excecao.BDException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Ana Toledano
 */
public class ClienteDAO {
    public void inserir(Cliente cliente) throws BDException{
        Connection conexao = null;
        PreparedStatement instrucao = null;
        String sql = "insert into cliente (clinome, cliendereco, clitelefone, clicidcodigo) "
                + "values (?, ?, ?, ?)";
        
        try{
            conexao = ControlaConexao.getConexao();
            instrucao = conexao.prepareStatement(sql);
            
            instrucao.setString(1, cliente.getNome());
            instrucao.setString(2, cliente.getEndereco());
            instrucao.setString(3, cliente.getTelefone());
            instrucao.setLong(4, cliente.getCidade().getId());
            
            instrucao.execute();
        } catch (SQLException ex){
            throw new BDException(ex);
        }finally{
            ControlaConexao.fecharInstrucao(instrucao);
            ControlaConexao.fecharConexao(conexao);
        }
        
        
    }
    
    public void deletar (Cliente cliente) throws BDException{
        String sql = "delete from cliente where clicodigo = ?";
        Connection conexao = null;
        PreparedStatement instrucao = null;
        
        try{
            conexao = ControlaConexao.getConexao();
            instrucao = conexao.prepareStatement(sql);
            
            instrucao.setLong(1, cliente.getId());
            
            instrucao.execute();
        } catch (SQLException ex){
            throw new BDException(ex);
        }finally{
            ControlaConexao.fecharInstrucao(instrucao);
            ControlaConexao.fecharConexao(conexao);
        }
        
    }
    
    public void alterar (Cliente cliente) throws BDException{
        Connection conexao = null;
        PreparedStatement instrucao = null;
        String sql = "update cliente set clinome = ?, cliendereco = ?, clitelefone = ?, clicidcodigo = ? "
                + "where clicodigo = ?";
        
        try{
            conexao = ControlaConexao.getConexao();
            instrucao = conexao.prepareStatement(sql);
            
            instrucao.setString(1, cliente.getNome());
            instrucao.setString(2, cliente.getEndereco());
            instrucao.setString(3, cliente.getTelefone());
            instrucao.setLong(4, cliente.getCidade().getId());
            instrucao.setLong(5, cliente.getId());
            
            instrucao.execute();
        } catch (SQLException ex){
            throw new BDException(ex);
        }finally{
            ControlaConexao.fecharInstrucao(instrucao);
            ControlaConexao.fecharConexao(conexao);
        }
    }
    
    public Cliente consultar (Cliente cliente) throws BDException{
        String sql = "select clinome, cliendereco, clitelefone, clicidcodigo, cidnome, cidestcodigo, estnome "
                + "from cliente, cidade, estado "
                + "where clicodigo = ? && clicidcodigo = cidcodigo && cidestcodigo = estcodigo";
        Connection conexao = null;
        PreparedStatement instrucao = null;
        ResultSet resultado;
        Cidade cidade = new Cidade();
        Estado estado = new Estado();
        
        try{
            conexao = ControlaConexao.getConexao();
            instrucao = conexao.prepareStatement(sql);
            
            instrucao.setLong(1, cliente.getId());
            
            resultado = instrucao.executeQuery();
            resultado.next();
            
            estado.setId(resultado.getLong("cidestcodigo"));
            estado.setNome(resultado.getString("estnome"));
            cidade.setId(resultado.getLong("clicidcodigo"));
            cidade.setNome(resultado.getString("cidnome"));
            cidade.setEstado(estado);
            cliente.setNome(resultado.getString("clinome"));
            cliente.setEndereco(resultado.getString("cliendereco"));
            cliente.setTelefone(resultado.getString("clitelefone"));
            cliente.setCidade(cidade);
            
            return cliente;
        } catch (SQLException ex){
            throw new BDException(ex);
        }finally{
            ControlaConexao.fecharInstrucao(instrucao);
            ControlaConexao.fecharConexao(conexao);
        }
    }
    
    public List<Cliente> pesquisar (Cliente cliente) throws BDException{
        List<Cliente> clientes = new ArrayList();
        Connection conexao = null;
        PreparedStatement instrucao = null;
        ResultSet resultado;
        String sql = "select clicodigo, clinome, clitelefone "
                + "from cliente "
                + "where clinome like ? && clitelefone like ?"
                + "order by clinome";
        
        try{
            conexao = ControlaConexao.getConexao();
            instrucao = conexao.prepareStatement(sql);
            
            instrucao.setString(1, "%" + cliente.getNome() + "%");
            instrucao.setString(2, "%" + cliente.getTelefone()+ "%");
            resultado = instrucao.executeQuery();
            
            while (resultado.next()){
                Cliente clienteAux = new Cliente();
                clienteAux.setId(resultado.getLong("clicodigo"));
                clienteAux.setNome(resultado.getString("clinome"));
                clienteAux.setTelefone(resultado.getString("clitelefone"));
                
                clientes.add(clienteAux);
            }
            
            return clientes;
        } catch (SQLException ex){
            throw new BDException(ex);
        }finally{
            ControlaConexao.fecharInstrucao(instrucao);
            ControlaConexao.fecharConexao(conexao);
        }
    }
}
