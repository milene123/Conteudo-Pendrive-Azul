/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Modelo.Produto;
import excecao.BDException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Ana Toledano
 */
public class ProdutoDAO {
    public void inserir(Produto produto) throws BDException{
        Connection conexao = null;
        PreparedStatement instrucao = null;
        String sql = "insert into produto (prodescricao) "
                + "values (?)";
        
        try{
            conexao = ControlaConexao.getConexao();
            instrucao = conexao.prepareStatement(sql);
            
            instrucao.setString(1, produto.getDescricao());
            
            instrucao.execute();
        } catch (SQLException ex){
            throw new BDException(ex);
        }finally{
            ControlaConexao.fecharInstrucao(instrucao);
            ControlaConexao.fecharConexao(conexao);
        }
        
        
    }
    
    public void deletar (Produto produto) throws BDException{
        String sql = "delete from produto where procodigo = ?";
        Connection conexao = null;
        PreparedStatement instrucao = null;
        
        try{
            conexao = ControlaConexao.getConexao();
            instrucao = conexao.prepareStatement(sql);
            
            instrucao.setLong(1, produto.getId());
            
            instrucao.execute();
        } catch (SQLException ex){
            throw new BDException(ex);
        }finally{
            ControlaConexao.fecharInstrucao(instrucao);
            ControlaConexao.fecharConexao(conexao);
        }
        
    }
    
    public void alterar (Produto produto) throws BDException{
        Connection conexao = null;
        PreparedStatement instrucao = null;
        String sql = "update produto set prodescricao = ? "
                + "where procodigo = ?";
        
        try{
            conexao = ControlaConexao.getConexao();
            instrucao = conexao.prepareStatement(sql);
            
            instrucao.setString(1, produto.getDescricao());
            instrucao.setLong(2, produto.getId());
            
            instrucao.execute();
        } catch (SQLException ex){
            throw new BDException(ex);
        }finally{
            ControlaConexao.fecharInstrucao(instrucao);
            ControlaConexao.fecharConexao(conexao);
        }
    }
    
    public Produto consultar (Produto produto) throws BDException{
        String sql = "select prodescricao "
                + "from produto "
                + "where procodigo = ?";
        Connection conexao = null;
        PreparedStatement instrucao = null;
        ResultSet resultado;
        
        try{
            conexao = ControlaConexao.getConexao();
            instrucao = conexao.prepareStatement(sql);
            
            instrucao.setLong(1, produto.getId());
            
            resultado = instrucao.executeQuery();
            resultado.next();
            
            produto.setDescricao(resultado.getString("prodescricao"));
            
            return produto;
        } catch (SQLException ex){
            throw new BDException(ex);
        }finally{
            ControlaConexao.fecharInstrucao(instrucao);
            ControlaConexao.fecharConexao(conexao);
        }
    }
    
    public List<Produto> pesquisar (Produto produto) throws BDException{
        List<Produto> produtos = new ArrayList();
        Connection conexao = null;
        PreparedStatement instrucao = null;
        ResultSet resultado;
        String sql = "select procodigo, prodescricao "
                + "from produto "
                + "where procodigo like ? && prodescricao like ?"
                + "order by prodescricao";
        
        try{
            conexao = ControlaConexao.getConexao();
            instrucao = conexao.prepareStatement(sql);
            
            if(produto.getId() != 0){ //igual a 0 se o atributo Id não foi setado
                instrucao.setString(1, "%" + produto.getId()+ "%");
            }else{
                instrucao.setString(1, "%" + "" + "%");
            }
            
            instrucao.setString(2, "%" + produto.getDescricao()+ "%");
            resultado = instrucao.executeQuery();
            
            while (resultado.next()){
                Produto produtoAux = new Produto();
                produtoAux.setId(resultado.getLong("procodigo"));
                produtoAux.setDescricao(resultado.getString("prodescricao"));
                
                produtos.add(produtoAux);
            }
            
            return produtos;
        } catch (SQLException ex){
            throw new BDException(ex);
        }finally{
            ControlaConexao.fecharInstrucao(instrucao);
            ControlaConexao.fecharConexao(conexao);
        }
    }
}
