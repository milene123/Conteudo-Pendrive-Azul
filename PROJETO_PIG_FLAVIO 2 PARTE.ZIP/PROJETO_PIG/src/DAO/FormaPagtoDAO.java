/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Modelo.FormaPagto;
import excecao.BDException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Ana Toledano
 */
public class FormaPagtoDAO {
    public void inserir(FormaPagto formaPagto) throws BDException{
        Connection conexao = null;
        PreparedStatement instrucao = null;
        String sql = "insert into formaPagto (fordescricao, forqtdeparcelas) "
                + "values (?, ?)";
        
        try{
            conexao = ControlaConexao.getConexao();
            instrucao = conexao.prepareStatement(sql);
            
            instrucao.setString(1, formaPagto.getDescricao());
            instrucao.setInt(2, formaPagto.getQtdeParcelas());
            
            instrucao.execute();
        } catch (SQLException ex){
            throw new BDException(ex);
        }finally{
            ControlaConexao.fecharInstrucao(instrucao);
            ControlaConexao.fecharConexao(conexao);
        }
        
        
    }
    
    public void deletar (FormaPagto formaPagto) throws BDException{
        String sql = "delete from formapagto where forcodigo = ?";
        Connection conexao = null;
        PreparedStatement instrucao = null;
        
        try{
            conexao = ControlaConexao.getConexao();
            instrucao = conexao.prepareStatement(sql);
            
            instrucao.setLong(1, formaPagto.getId());
            
            instrucao.execute();
        } catch (SQLException ex){
            throw new BDException(ex);
        }finally{
            ControlaConexao.fecharInstrucao(instrucao);
            ControlaConexao.fecharConexao(conexao);
        }
        
    }
    
    public void alterar (FormaPagto formaPagto) throws BDException{
        Connection conexao = null;
        PreparedStatement instrucao = null;
        String sql = "update formapagto set fordescricao = ?, forqtdeparcelas = ? "
                + "where forcodigo = ?";
        
        try{
            conexao = ControlaConexao.getConexao();
            instrucao = conexao.prepareStatement(sql);
            
            instrucao.setString(1, formaPagto.getDescricao());
            instrucao.setInt(2, formaPagto.getQtdeParcelas());
            instrucao.setLong(3, formaPagto.getId());
            
            instrucao.execute();
        } catch (SQLException ex){
            throw new BDException(ex);
        }finally{
            ControlaConexao.fecharInstrucao(instrucao);
            ControlaConexao.fecharConexao(conexao);
        }
    }
    
    public FormaPagto consultar (FormaPagto formaPagto) throws BDException{
        String sql = "select fordescricao, forqtdeparcelas "
                + "from formaPagto "
                + "where forcodigo = ?";
        Connection conexao = null;
        PreparedStatement instrucao = null;
        ResultSet resultado;
        
        try{
            conexao = ControlaConexao.getConexao();
            instrucao = conexao.prepareStatement(sql);
            
            instrucao.setLong(1, formaPagto.getId());
            
            resultado = instrucao.executeQuery();
            resultado.next();
            
            formaPagto.setDescricao(resultado.getString("fordescricao"));
            formaPagto.setQtdeParcelas(resultado.getInt("forqtdeparcelas"));
            
            return formaPagto;
        } catch (SQLException ex){
            throw new BDException(ex);
        }finally{
            ControlaConexao.fecharInstrucao(instrucao);
            ControlaConexao.fecharConexao(conexao);
        }
    }
    
    public List<FormaPagto> pesquisar (FormaPagto formaPagto) throws BDException{
        List<FormaPagto> formaPagtos = new ArrayList();
        Connection conexao = null;
        PreparedStatement instrucao = null;
        ResultSet resultado;
        String sql = "select forcodigo, fordescricao, forqtdeparcelas "
                + "from formaPagto "
                + "where fordescricao like ?"
                + "order by fordescricao";
        
        try{
            conexao = ControlaConexao.getConexao();
            instrucao = conexao.prepareStatement(sql);
            
            instrucao.setString(1, "%" + formaPagto.getDescricao()+ "%");
            resultado = instrucao.executeQuery();
            
            while (resultado.next()){
                FormaPagto formaPagtoAux = new FormaPagto();
                formaPagtoAux.setId(resultado.getLong("forcodigo"));
                formaPagtoAux.setDescricao(resultado.getString("fordescricao"));
                formaPagtoAux.setQtdeParcelas(resultado.getInt("forqtdeparcelas"));
                
                formaPagtos.add(formaPagtoAux);
            }
            
            return formaPagtos;
        } catch (SQLException ex){
            throw new BDException(ex);
        }finally{
            ControlaConexao.fecharInstrucao(instrucao);
            ControlaConexao.fecharConexao(conexao);
        }
    }
}
