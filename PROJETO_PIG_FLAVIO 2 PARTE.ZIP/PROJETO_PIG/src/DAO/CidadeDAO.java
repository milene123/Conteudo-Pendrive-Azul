/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Modelo.Cidade;
import Modelo.Estado;
import excecao.BDException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Ana Toledano
 */
public class CidadeDAO {
    
    public void inserir(Cidade cidade) throws BDException{
        Connection conexao = null;
        PreparedStatement instrucao = null;
        String sql = "insert into cidade (cidnome, cidestcodigo) "
                + "values (?, ?)";
        
        try{
            conexao = ControlaConexao.getConexao();
            instrucao = conexao.prepareStatement(sql);
            
            instrucao.setString(1, cidade.getNome());
            instrucao.setLong(2, cidade.getEstado().getId());
            
            instrucao.execute();
        } catch (SQLException ex){
            throw new BDException(ex);
        }finally{
            ControlaConexao.fecharInstrucao(instrucao);
            ControlaConexao.fecharConexao(conexao);
        }
        
        
    }
    
    public void deletar (Cidade cidade) throws BDException{
        String sql = "delete from cidade where cidcodigo = ?";
        Connection conexao = null;
        PreparedStatement instrucao = null;
        
        try{
            conexao = ControlaConexao.getConexao();
            instrucao = conexao.prepareStatement(sql);
            
            instrucao.setLong(1, cidade.getId());
            
            instrucao.execute();
        } catch (SQLException ex){
            throw new BDException(ex);
        }finally{
            ControlaConexao.fecharInstrucao(instrucao);
            ControlaConexao.fecharConexao(conexao);
        }
        
    }
    
    public void alterar (Cidade cidade) throws BDException{
        Connection conexao = null;
        PreparedStatement instrucao = null;
        String sql = "update cidade set cidnome = ?, cidestcodigo = ? where cidcodigo = ?";
        
        try{
            conexao = ControlaConexao.getConexao();
            instrucao = conexao.prepareStatement(sql);
            
            instrucao.setString(1, cidade.getNome());
            instrucao.setLong(2, cidade.getEstado().getId());
            instrucao.setLong(3, cidade.getId());
            
            instrucao.execute();
        } catch (SQLException ex){
            throw new BDException(ex);
        }finally{
            ControlaConexao.fecharInstrucao(instrucao);
            ControlaConexao.fecharConexao(conexao);
        }
    }
    
    public Cidade consultar (Cidade cidade) throws BDException{
        String sql = "select cidcodigo, cidnome, cidestcodigo, estnome "
                + "from cidade, estado "
                + "where cidcodigo = ? && cidestcodigo = estcodigo";
        Connection conexao = null;
        PreparedStatement instrucao = null;
        ResultSet resultado;
        
        try{
            conexao = ControlaConexao.getConexao();
            instrucao = conexao.prepareStatement(sql);
            
            instrucao.setLong(1, cidade.getId());
            
            resultado = instrucao.executeQuery();
            resultado.next();
            
            cidade.setId(resultado.getLong("cidcodigo"));
            cidade.setNome(resultado.getString("cidnome"));
            cidade.setEstado(new Estado());
            cidade.getEstado().setId(resultado.getLong("cidestcodigo"));
            cidade.getEstado().setNome(resultado.getString("estnome"));
            
            return cidade;
        } catch (SQLException ex){
            throw new BDException(ex);
        }finally{
            ControlaConexao.fecharInstrucao(instrucao);
            ControlaConexao.fecharConexao(conexao);
        }
    }
    
    public List<Cidade> pesquisar (Cidade cidade) throws BDException{
        List<Cidade> cidades = new ArrayList();
        Connection conexao = null;
        PreparedStatement instrucao = null;
        ResultSet resultado;
        String sql = "select cidcodigo, cidnome "
                + "from cidade "
                + "where cidnome like ? ";
        
        try{
            conexao = ControlaConexao.getConexao();
            instrucao = conexao.prepareStatement(sql);
            
            instrucao.setString(1, "%" + cidade.getNome() + "%");
            resultado = instrucao.executeQuery();
            
            while (resultado.next()){
                Cidade c = new Cidade();
                c.setId(resultado.getLong("cidcodigo"));
                c.setNome(resultado.getString("cidnome"));
                
                cidades.add(c);
            }
            
            return cidades;
        } catch (SQLException ex){
            throw new BDException(ex);
        }finally{
            ControlaConexao.fecharInstrucao(instrucao);
            ControlaConexao.fecharConexao(conexao);
        }
    }
}
