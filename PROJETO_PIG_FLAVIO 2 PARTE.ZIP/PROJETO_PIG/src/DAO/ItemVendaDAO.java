/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Modelo.ItemVenda;
import Modelo.Produto;
import Modelo.Venda;
import excecao.BDException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class ItemVendaDAO {
    public void inserir(ItemVenda itemVenda) throws BDException{
        Connection conexao = null;
        PreparedStatement instrucao = null;
        String sql = "insert into itemvenda (itvqtde, itvvencodigo, itvprocodigo) "
                + "values (?, ?, ?)";
        
        try{
            conexao = ControlaConexao.getConexao();
            instrucao = conexao.prepareStatement(sql);
            
            instrucao.setInt(1, itemVenda.getQtde());
            instrucao.setLong(2, itemVenda.getVenda().getId());
            instrucao.setLong(3, itemVenda.getProduto().getId());
            
            instrucao.execute();
        } catch (SQLException ex){
            throw new BDException(ex);
        }finally{
            ControlaConexao.fecharInstrucao(instrucao);
            ControlaConexao.fecharConexao(conexao);
        }
        
        
    }
    
    public void deletar (ItemVenda itemVenda) throws BDException{
        String sql = "delete from itemVenda where itvcodigo = ?";
        Connection conexao = null;
        PreparedStatement instrucao = null;
        
        try{
            conexao = ControlaConexao.getConexao();
            instrucao = conexao.prepareStatement(sql);
            
            instrucao.setLong(1, itemVenda.getId());
            
            instrucao.execute();
        } catch (SQLException ex){
            throw new BDException(ex);
        }finally{
            ControlaConexao.fecharInstrucao(instrucao);
            ControlaConexao.fecharConexao(conexao);
        }
        
    }
    
    public void alterar (ItemVenda itemVenda) throws BDException{
        Connection conexao = null;
        PreparedStatement instrucao = null;
        String sql = "update itemVenda set itvqtde = ?, itvvencodigo = ?, itvprocodigo= ? "
                + "where itvcodigo = ?";
        
        try{
            conexao = ControlaConexao.getConexao();
            instrucao = conexao.prepareStatement(sql);
            
            instrucao.setInt(1, itemVenda.getQtde());
            instrucao.setLong(2, itemVenda.getVenda().getId());
            instrucao.setLong(3, itemVenda.getProduto().getId());
            instrucao.setLong(4, itemVenda.getId());
            
            instrucao.execute();
        } catch (SQLException ex){
            throw new BDException(ex);
        }finally{
            ControlaConexao.fecharInstrucao(instrucao);
            ControlaConexao.fecharConexao(conexao);
        }
    }
    
    public ItemVenda consultar (ItemVenda itemVenda) throws BDException{
        String sql = "select itvqtde, itvvencodigo, vendata, itvprocodigo, prodescricao "
                + "from itemVenda, venda, produto "
                + "where itvcodigo = ? && itvvencodigo= vencodigo && itvprocodigo = procodigo";
        Connection conexao = null;
        PreparedStatement instrucao = null;
        ResultSet resultado;
        Venda venda = new Venda();
        Produto produto = new Produto();
        
        try{
            conexao = ControlaConexao.getConexao();
            instrucao = conexao.prepareStatement(sql);
            
            instrucao.setLong(1, itemVenda.getId());
            
            resultado = instrucao.executeQuery();
            resultado.next();
            
            venda.setId(resultado.getLong("itvvencodigo"));
            venda.setData(resultado.getDate("vendata"));
            produto.setId(resultado.getLong("itvprocodigo"));
            produto.setDescricao(resultado.getString("prodescricao"));
            itemVenda.setQtde(resultado.getInt("itvqtde"));
            itemVenda.setVenda(venda);
            itemVenda.setProduto(produto);
            
            return itemVenda;
        } catch (SQLException ex){
            throw new BDException(ex);
        }finally{
            ControlaConexao.fecharInstrucao(instrucao);
            ControlaConexao.fecharConexao(conexao);
        }
    }
    
    public List<ItemVenda> pesquisar (ItemVenda itemVenda) throws BDException{
        List<ItemVenda> itemVendas = new ArrayList();
        Connection conexao = null;
        PreparedStatement instrucao = null;
        ResultSet resultado;
        String sql = "select itvcodigo, itvqtde, prodescricao " +
                "from itemVenda, venda, produto " +
                "where itvvencodigo = ? && itvvencodigo = vencodigo && itvprocodigo = procodigo";
        
        try{
            conexao = ControlaConexao.getConexao();
            instrucao = conexao.prepareStatement(sql);
            
            //Valida o ID da Venda para atribuir à variável 'instrucao'
            if( itemVenda.getVenda().getId() != 0){
                instrucao.setLong(1, itemVenda.getVenda().getId());
            }else{
                throw new BDException(new Exception());
            }
            
            resultado = instrucao.executeQuery();
            
            while (resultado.next()){
                ItemVenda itemVendaAux = new ItemVenda();
                Produto produto = new Produto();
                
                produto.setDescricao(resultado.getString("prodescricao"));
                itemVendaAux.setId(resultado.getLong("itvcodigo"));
                itemVendaAux.setQtde(resultado.getInt("itvqtde"));
                itemVendaAux.setProduto(produto);
                
                itemVendas.add(itemVendaAux);
            }
            
            return itemVendas;
        } catch (SQLException ex){
            throw new BDException(ex);
        }finally{
            ControlaConexao.fecharInstrucao(instrucao);
            ControlaConexao.fecharConexao(conexao);
        }
    }
}