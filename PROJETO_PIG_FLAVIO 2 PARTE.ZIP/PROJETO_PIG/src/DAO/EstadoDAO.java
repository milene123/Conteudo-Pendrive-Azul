
package DAO;

import Modelo.Estado;
import excecao.BDException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EstadoDAO {
    public void inserir (Estado estado) throws BDException{
        String sql = "insert into estado (estnome) values (?)";
        Connection  conexao= null;
        PreparedStatement instrucao = null;
       
        try{
            conexao = ControlaConexao.getConexao();
            instrucao = conexao.prepareStatement(sql);     
            
            instrucao.setString(1, estado.getNome());
            instrucao.execute();
        }catch(SQLException e){
            throw new BDException(e);
            
        }finally{
            ControlaConexao.fecharInstrucao(instrucao);
            ControlaConexao.fecharConexao(conexao);
            }   
               
    
    }
    
    public void deletar (Estado estado) throws BDException{
        String sql = "delete from estado where estcodigo = ?";
        Connection  conexao= null;
        PreparedStatement instrucao = null;
        try{
            conexao = ControlaConexao.getConexao();
            instrucao = conexao.prepareStatement(sql);
            
            instrucao.setLong(1, estado.getId());
            
            instrucao.execute();
            
        }catch(SQLException e){
            throw new BDException(e);
        }finally{
            ControlaConexao.fecharInstrucao(instrucao);
            ControlaConexao.fecharConexao(conexao);
            }
      
    }
    
    public void alterar(Estado estado) throws BDException{
        String sql = "update estado set estnome=? where estcodigo=?";
        Connection  conexao= null;
        PreparedStatement instrucao = null;
        try{
            conexao = ControlaConexao.getConexao();
            instrucao = conexao.prepareStatement(sql);
            
            instrucao.setString(1, estado.getNome());
            instrucao.setLong(2, estado.getId());
            
            instrucao.execute();
            
        }catch(SQLException e){
            throw new BDException(e);
        }finally{
            ControlaConexao.fecharInstrucao(instrucao);
            ControlaConexao.fecharConexao(conexao);
            }
    }
    
    public List<Estado> pesquisar (Estado estado) throws BDException{
        Connection  conexao= null;
        PreparedStatement instrucao = null;
       
        try{
            conexao = ControlaConexao.getConexao();
            String sql = "select estcodigo, estnome from estado where estnome like ?";
            instrucao = conexao.prepareStatement(sql);     
            
            instrucao.setString(1, "%"+estado.getNome()+"%");
            instrucao.execute();
            
            ResultSet resultados = instrucao.getResultSet();
            Estado estadoAux;
            List<Estado> estados = new ArrayList<>();
            
            while(resultados.next()){
                estadoAux = new Estado();
                estadoAux.setId(resultados.getLong("estcodigo"));
                estadoAux.setNome(resultados.getString("estnome"));

                estados.add(estadoAux);
                }
	    return estados;
            
        }catch(SQLException e){
            throw new BDException(e);
            
        }finally{
            ControlaConexao.fecharInstrucao(instrucao);
            ControlaConexao.fecharConexao(conexao);
            }   
               
    
    }
    
    public Estado consultar(Estado estado) throws BDException{
        Connection  conexao= null;
        PreparedStatement instrucao = null;
       
        try{
            conexao = ControlaConexao.getConexao();
            String sql = "select estcodigo, estnome from estado where estcodigo like '%?%'";
            instrucao = conexao.prepareStatement(sql);     
            
            instrucao.setLong(1, estado.getId());
            instrucao.execute();
            
            ResultSet resultados = instrucao.getResultSet();
            
            Estado estadoAux = null;
            while(resultados.next()){
                estadoAux = new Estado();
                estadoAux.setId(resultados.getLong("id"));
                estadoAux.setNome(resultados.getString("nome"));
                
            }
            return estadoAux;
            
        }catch(SQLException e){
            throw new BDException(e);
            
        }finally{
            ControlaConexao.fecharInstrucao(instrucao);
            ControlaConexao.fecharConexao(conexao);
        }
    }
}