/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Modelo.Cliente;
import Modelo.FormaPagto;
import Modelo.Venda;
import excecao.BDException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.sql.Date;
import java.sql.Statement;

/**
 *
 * @author Ana Toledano
 */
public class VendaDAO {
    public Long inserir(Venda venda) throws BDException{
        Connection conexao = null;
        PreparedStatement instrucao = null;
        String sql = "insert into venda (vendata, venclicodigo, venforcodigo) "
                + "values (?, ?, ?); ";
        
        ResultSet resultado;
        
        try{
            conexao = ControlaConexao.getConexao();
            instrucao = conexao.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS); //o BD retorna o valor do autoincremento gerado
            
            java.sql.Date dataBD = new java.sql.Date(venda.getData().getTimeInMillis());// converte a data para o formato SQL
            
            instrucao.setDate(1, dataBD);
            instrucao.setLong(2, venda.getCliente().getId());
            instrucao.setLong(3, venda.getFormaPagto().getId());
            
            instrucao.execute();
            
            resultado = instrucao.getGeneratedKeys();// passa para o ResultSet o valor do autoincremento
            resultado.next();
            
            return resultado.getLong(1);
        } catch (SQLException ex){
            throw new BDException(ex);
        }finally{
            ControlaConexao.fecharInstrucao(instrucao);
            ControlaConexao.fecharConexao(conexao);
        }
    }
    
    public void deletar (Venda venda) throws BDException{
        String sql = "delete from venda where vencodigo = ?";
        Connection conexao = null;
        PreparedStatement instrucao = null;
        
        try{
            conexao = ControlaConexao.getConexao();
            instrucao = conexao.prepareStatement(sql);
            
            instrucao.setLong(1, venda.getId());
            
            instrucao.execute();
        } catch (SQLException ex){
            throw new BDException(ex);
        }finally{
            ControlaConexao.fecharInstrucao(instrucao);
            ControlaConexao.fecharConexao(conexao);
        }
        
    }
    
    public void alterar (Venda venda) throws BDException{
        Connection conexao = null;
        PreparedStatement instrucao = null;
        String sql = "update venda set vendata = ?, venclicodigo = ?, venforcodigo = ? "
                + "where vencodigo = ?";
        
        try{
            conexao = ControlaConexao.getConexao();
            instrucao = conexao.prepareStatement(sql);
            
            java.sql.Date dataBD = new Date(venda.getData().getTimeInMillis());
            
            instrucao.setDate(1, dataBD);
            instrucao.setLong(2, venda.getCliente().getId());
            instrucao.setLong(3, venda.getFormaPagto().getId());
            instrucao.setLong(4, venda.getId());
            
            instrucao.execute();
        } catch (SQLException ex){
            throw new BDException(ex);
        }finally{
            ControlaConexao.fecharInstrucao(instrucao);
            ControlaConexao.fecharConexao(conexao);
        }
    }
    
    public Venda consultar (Venda venda) throws BDException{
        String sql = "select vendata, venclicodigo, clinome, clitelefone , venforcodigo, fordescricao, forqtdeparcelas "
                + "from venda, cliente, formapagto "
                + "where vencodigo = ? && venclicodigo = clicodigo && venforcodigo = forcodigo";
        Connection conexao = null;
        PreparedStatement instrucao = null;
        ResultSet resultado;
        Cliente cliente = new Cliente();
        FormaPagto formaPagto = new FormaPagto();
        
        try{
            conexao = ControlaConexao.getConexao();
            instrucao = conexao.prepareStatement(sql);
            
            instrucao.setLong(1, venda.getId());
            resultado = instrucao.executeQuery();
            resultado.next();
            
            cliente.setId(resultado.getLong("venclicodigo"));
            cliente.setNome(resultado.getString("clinome"));
            cliente.setTelefone(resultado.getString("clitelefone"));
            formaPagto.setId(resultado.getLong("venforcodigo"));
            formaPagto.setDescricao(resultado.getString("fordescricao"));
            formaPagto.setQtdeParcelas(resultado.getInt("forqtdeparcelas"));
            
            venda.setData( resultado.getDate("vendata"));
            venda.setCliente(cliente);
            venda.setFormaPagto(formaPagto);
            
            return venda;
        } catch (SQLException ex){
            throw new BDException(ex);
        }finally{
            ControlaConexao.fecharInstrucao(instrucao);
            ControlaConexao.fecharConexao(conexao);
        }
    }
    
    public List<Venda> pesquisar (Venda venda) throws BDException{
        List<Venda> vendas = new ArrayList();
        Connection conexao = null;
        PreparedStatement instrucao = null;
        ResultSet resultado;
        String sql = "select vencodigo, vendata, clinome "
                + "from venda, cliente "
                + "where vencodigo like ? && vendata like ? && clinome like ? && venclicodigo = clicodigo";
        
        try{
            conexao = ControlaConexao.getConexao();
            instrucao = conexao.prepareStatement(sql);
            
            //Valida o ID da Venda para atribuir à variável 'instrucao'
            if(venda.getId() != 0){
                instrucao.setString(1, "%" + venda.getId() + "%");
            }else{
                instrucao.setString(1, "%" + "" + "%");
            }
            
            try{
                java.sql.Date dataBD = new Date(venda.getData().getTimeInMillis()); //Converte a data para o formatato do MySql
                instrucao.setString(2, "%" + dataBD + "%");
            } catch(Exception ex){
                instrucao.setString(2, "%" + "" + "%");
            }
            
            instrucao.setString(3, "%" + venda.getCliente().getNome() + "%");
            
            resultado = instrucao.executeQuery();
            
            while (resultado.next()){
                Venda vendaAux = new Venda();
                Cliente clienteAux = new Cliente();
                
                clienteAux.setNome(resultado.getString("clinome"));
                vendaAux.setId(resultado.getLong("vencodigo"));
                vendaAux.setData(resultado.getDate("vendata"));
                vendaAux.setCliente(clienteAux);
                
                vendas.add(vendaAux);
            }
            return vendas;
        } catch (SQLException ex){
            throw new BDException(ex);
        }finally{
            ControlaConexao.fecharInstrucao(instrucao);
            ControlaConexao.fecharConexao(conexao);
        }
    }
}
