/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package excecao;

import javax.swing.JOptionPane;

/**
 *
 * @author Ana Toledano
 */
public class BDException extends Exception{
    
    public BDException(Throwable t) {
        super(t);
        JOptionPane.showMessageDialog(null, "Houve uma falha enquanto o BD foi acessado!");
        System.out.println(" > Houve uma falha enquanto o BD foi acessado!");
        t.printStackTrace();
    }
}
