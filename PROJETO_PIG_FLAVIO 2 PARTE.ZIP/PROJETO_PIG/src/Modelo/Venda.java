/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 *
 * @author Ana Toledano
 */
public class Venda {
    private long id;
    private Calendar data;
    private Cliente cliente;
    private FormaPagto formaPagto;
    private List<ItemVenda> itens;
    
    

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }
    
    public void setId(String id){
        try{
            this.id = Long.parseLong(id);
        }catch(NumberFormatException nfe){
            //O ID não é setado caso tenha sido passado nenhum valor ou valor inválio
        }
    }

    public Calendar getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = Calendar.getInstance(); //Este método deve ser executado para trabalhar datas do tipo Calendar
        this.data.setTime(data);
    }
    
    public void setData(String dataString){
        SimpleDateFormat sdfBR = new SimpleDateFormat("dd/MM/yyyy"); //formata data no formato brasileiro
        SimpleDateFormat sdfEUA = new SimpleDateFormat("yyyy/MM/dd"); //formata data no formato americano
        
        try{
            Date data = sdfBR.parse(dataString);        /***Converte uma data em String do formato brasileiro   */
            dataString = sdfEUA.format(data.getTime()); /*  para um objeto da Classe Data no formato americano, */
            data = sdfEUA.parse(dataString);            /*  que é o formato do MySql                          ***/
            
            this.data = Calendar.getInstance();
            this.data.setTime(data);
        }catch(ParseException pe){
            //A data não é setada caso tenha sido passado nenhum valor ou valor inválio
        }
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public FormaPagto getFormaPagto() {
        return formaPagto;
    }

    public void setFormaPagto(FormaPagto formaPagto) {
        this.formaPagto = formaPagto;
    }

    public List<ItemVenda> getItens() {
        return itens;
    }

    public void setItens(List<ItemVenda> itens) {
        this.itens = itens;
    }
    
    
}
