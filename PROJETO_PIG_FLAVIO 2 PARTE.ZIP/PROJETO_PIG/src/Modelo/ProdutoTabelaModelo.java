/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Milene Souza
 */
public class ProdutoTabelaModelo extends AbstractTableModel{
    private List<Produto>produtos;
    public  ProdutoTabelaModelo(List<Produto> produtos){
        this.produtos = produtos;
    }
    
    @Override
    public int getRowCount() {//linha
        return produtos.size();
    }

    @Override
    public int getColumnCount() {//coluna
        return 2;
    }
    
    public String getColumnName(int coluna) {
        switch(coluna){
            case 0 : return "Código";
            case 1 : return "Descrição";
        }
        return null;
    }
    public Object getValueAt(int linha, int coluna) {
        Produto  produto  = produtos.get(linha);
        
        switch(coluna){
            case 0: return produto.getId();   
            case 1: return produto.getDescricao();
        }
        return null;
        
    }
      
}

