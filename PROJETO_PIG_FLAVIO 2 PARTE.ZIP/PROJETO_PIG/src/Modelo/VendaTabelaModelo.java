
package Modelo;

import java.text.SimpleDateFormat;
import java.util.List;
import javax.swing.table.AbstractTableModel;


public class VendaTabelaModelo extends AbstractTableModel
{
    List<Venda> vendas;
    
    public VendaTabelaModelo( List<Venda> vendas ){
        this.vendas = vendas;
    }

    @Override
    public int getRowCount(){
        return vendas.size();
    }

    @Override
    public int getColumnCount(){
        return 3;        
    }
    
    public String getColumnName(int coluna){
        switch (coluna){
            case 0: return "Número";
            case 1: return "Data";
            case 2: return "Cliente";
        }
        return null;
    }

    @Override
    public Object getValueAt(int linha, int coluna){
        Venda venda = vendas.get(linha);
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        
        System.out.println("\ngetValueAt: linha: " + linha + "    coluna: " + coluna);
        
        switch(coluna){
            case 0 : {
                System.out.println("venda.getId(): " + venda.getId());
                return venda.getId();
            }
            case 1 : {
                System.out.println("sdf.format(venda.getData().getTime()): " + sdf.format(venda.getData().getTime()));
                return sdf.format(venda.getData().getTime());
            }
            case 2 : {
                System.out.println("venda.getCliente().getNome(): " + venda.getCliente().getNome());
                return venda.getCliente().getNome();
            }
        }
        
        return null;
    }
    
}
