/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.util.List;
import javax.swing.table.AbstractTableModel;

public class FormaPagtoTabelaModelo extends AbstractTableModel{
    private List<FormaPagto>formaPagtos;
    public  FormaPagtoTabelaModelo(List<FormaPagto> formaPagtos){
        this.formaPagtos = formaPagtos;
    }
    
    public int getRowCount() {//linha
        return formaPagtos.size();
    }

    public int getColumnCount() {//coluna
        return 2;
    }

    
    public String getColumnName(int coluna) {
        /*if(coluna == 0){
            return "nome";
        }else if(coluna == 1){
            return "e";
        }else if(coluna == 2){
            return "endereco";
        }else if(coluna == 3){
            return "telefone";
        }*/
        switch(coluna){
            
            case 0 : return "Descricao";
            case 1: return "Quantidade de Parcelas";
            //case 6: return  "Estado";
        }
        return null;
    }
    public Object getValueAt(int linha, int coluna) {
        FormaPagto formaPagto = formaPagtos.get(linha);
        
        switch(coluna){
            case 0: return formaPagto.getDescricao(); 
            case 1: return formaPagto.getQtdeParcelas();
            //case 4: return pessoa.getBairro().getBainome();
            //case 5: return pessoa.getPesbairro().getCidade().getEstado();
           //case 5: return pessoa.getBairro().getBaicidid();
            
        }
        return null;
        
    }
    
}
