/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.util.List;
import javax.swing.table.AbstractTableModel;


public class ItemVendaTabelaModelo extends AbstractTableModel{
private List<ItemVenda> itemVendas;
    
    public ItemVendaTabelaModelo(List<ItemVenda> itemVendas){
        this.itemVendas = itemVendas;
    }
    
    public int getRowCount() {//linha
        return itemVendas.size();
    }

    public int getColumnCount() {//coluna
        return 2;
    }

    
    public String getColumnName(int coluna) {
        switch(coluna){
            case 0 : return "Produto";
            case 1: return "Quantidade";
        }
        return null;
    }

    public Object getValueAt(int linha, int coluna) {
        ItemVenda itemVenda = itemVendas.get(linha);
        
        switch(coluna){
            case 0: return itemVenda.getProduto().getDescricao(); 
            case 1: return itemVenda.getQtde();
            
        }
        return null;
        
    }
    
}

