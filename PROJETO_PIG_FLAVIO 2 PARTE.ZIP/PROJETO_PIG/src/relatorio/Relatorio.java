/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package relatorio;

import DAO.ControlaConexao;
import excecao.BDException;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.view.JasperViewer;


public class Relatorio
{
    public static void main(String[] args) throws BDException, JRException, SQLException, ParseException
    {
        Relatorio r = new Relatorio();
        r.vendasPorPeriodo();
    }
    public void vendasPorPeriodo() throws BDException, JRException, SQLException, ParseException{
        Connection con = ControlaConexao.getConexao();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
        Calendar dataInicial = Calendar.getInstance();
        Calendar dataFinal = Calendar.getInstance();
        Map parametros = new HashMap();
        
        dataInicial.setTime(sdf.parse("2012/06/20"));
        dataFinal.setTime(sdf.parse("2016/06/27"));
        
        java.sql.Date dataInicialDB = new java.sql.Date(dataInicial.getTimeInMillis());
        java.sql.Date dataFinalDB = new java.sql.Date(dataFinal.getTimeInMillis());
        
        parametros.put("datainicial", dataInicialDB);
        parametros.put("datafinal", dataFinalDB);
        
        JasperPrint jp = JasperFillManager.fillReport( "C:\\Users\\flavio\\Documents\\Didático\\TDS\\3º\\PIG\\projeto final\\PROJETO_PIG\\Relatorios\\vendasPorPeriodo.jasper", parametros, con);
        JasperExportManager.exportReportToPdfFile (jp, "C:\\Users\\flavio\\Documents\\Didático\\TDS\\3º\\PIG\\projeto final\\PROJETO_PIG\\Relatorios\\vendasPorPeriodo.pdf");
        JasperViewer jv = new JasperViewer(jp, false);
        jv.setVisible(true);
        System.out.println("Relatório Gerado!");
    }
    
    public void clientesPorCidade() throws BDException, JRException, SQLException{
        Connection con = ControlaConexao.getConexao();
        Map parametros = new HashMap();
        
        parametros.put("cidCodigo", 4);
        
        JasperPrint jp = JasperFillManager.fillReport( "C:\\Users\\flavio\\Documents\\Didático\\TDS\\3º\\PIG\\projeto final\\PROJETO_PIG\\Relatorios\\clientesPorCidade.jasper", parametros, con);
        JasperExportManager.exportReportToPdfFile(jp, "C:\\Users\\flavio\\Documents\\Didático\\TDS\\3º\\PIG\\projeto final\\PROJETO_PIG\\Relatorios\\clientesPorCidade.pdf");
        JasperViewer jv = new JasperViewer(jp, false);
        jv.setVisible(true);
        System.out.println("Relatório Gerado!");
    }
}
