/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tela.formaPagto;

import DAO.FormaPagtoDAO;
import Modelo.FormaPagto;
import excecao.BDException;
import javax.swing.JOptionPane;


public class AlteraFormaPagtoTela extends javax.swing.JFrame {
     
    FormaPagto formaPagto;
    ConsultaFormaPagtoTela telaConsulta;
    
    
    public AlteraFormaPagtoTela() {
        initComponents();
    }
    public AlteraFormaPagtoTela(FormaPagto formaPagto, ConsultaFormaPagtoTela telaConsultaFormaPagto){
        this(); //aqui ele chama o construtor acima! ou seja, inicia os componentes
        this.formaPagto = formaPagto;
        this.telaConsulta = telaConsulta;
        carregaCampos();
    }
    
    private void carregaCampos(){
        campoAlteraDescricao.setText(formaPagto.getDescricao());
        campoAlteraQtdeParcelas.setText(Integer.toString(formaPagto.getQtdeParcelas()));
    }
    
   
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents()
    {

        jLabel1 = new javax.swing.JLabel();
        campoAlteraDescricao = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        campoAlteraQtdeParcelas = new javax.swing.JTextField();
        btSalvar = new javax.swing.JButton();
        btRetornar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Alterar Forma de Pagamento");

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setText("Descrição:");

        campoAlteraDescricao.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setText("Quantidade de Parcelas:");

        campoAlteraQtdeParcelas.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        btSalvar.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btSalvar.setText("Salvar");
        btSalvar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btSalvar.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btSalvarActionPerformed(evt);
            }
        });

        btRetornar.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btRetornar.setText("Retornar");
        btRetornar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btRetornar.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btRetornarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btSalvar, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(51, 51, 51)
                        .addComponent(btRetornar, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel2)
                    .addComponent(jLabel1)
                    .addComponent(campoAlteraQtdeParcelas)
                    .addComponent(campoAlteraDescricao))
                .addGap(0, 21, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(campoAlteraDescricao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(campoAlteraQtdeParcelas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btSalvar, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btRetornar, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(23, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btSalvarActionPerformed
        int resposta = JOptionPane.showConfirmDialog(null, "Confirmar Alteracao?", "ALTERAR", JOptionPane.YES_NO_OPTION);
        if(resposta == 0){       
            atualizarBD();
            dispose();
        }
    }//GEN-LAST:event_btSalvarActionPerformed

    private void btRetornarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btRetornarActionPerformed
        dispose();
    }//GEN-LAST:event_btRetornarActionPerformed

     private void atualizarBD(){
        formaPagto.setDescricao(campoAlteraDescricao.getText());//Se nao setar os valor na hora da atualização nao modificar os valores.
        formaPagto.setQtdeParcelas(Integer.parseInt(campoAlteraQtdeParcelas.getText()));
       
        try{
            FormaPagtoDAO dao = new FormaPagtoDAO();
            dao.alterar(formaPagto);
        }catch(BDException e){
            JOptionPane.showMessageDialog(this, "Ocorreu um erro de banco de dados" );
        }
     }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btRetornar;
    private javax.swing.JButton btSalvar;
    private javax.swing.JTextField campoAlteraDescricao;
    private javax.swing.JTextField campoAlteraQtdeParcelas;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    // End of variables declaration//GEN-END:variables
}
