/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tela.formaPagto;

import DAO.FormaPagtoDAO;
import Modelo.FormaPagto;
import excecao.BDException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;


public class ConsultaFormaPagtoTela extends javax.swing.JFrame {

    public PesquisaFormaPagtoTela telaPrincipal;
    public FormaPagto formaPagto;
    public AlteraFormaPagtoTela telaAlterar;
    public List<FormaPagto> formaPagtos = new ArrayList<>();
    
    public ConsultaFormaPagtoTela() {
        initComponents();
    }
    private void removerBD(){
        FormaPagtoDAO dao = new FormaPagtoDAO();
        try{
            dao.deletar(formaPagto);
        }catch(BDException e){
            JOptionPane.showMessageDialog(this, "Ocorreu um erro de banco de dados");
        }
    }
    public ConsultaFormaPagtoTela(FormaPagto formaPagtoSelecionada, PesquisaFormaPagtoTela telaConsultaFormaPagto, List<FormaPagto> formaPagtos){
        initComponents();
        this.formaPagtos = formaPagtos;
        this.telaPrincipal = telaConsultaFormaPagto;
        this.formaPagto = formaPagtoSelecionada;
        carregaLabels();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents()
    {

        jLabel1 = new javax.swing.JLabel();
        jLabelDecricao = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabelQtdeParcelas = new javax.swing.JLabel();
        btAlterar = new javax.swing.JButton();
        btRemover = new javax.swing.JButton();
        btRetornar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Detalhar Forma de Pagamento");

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setText("Descrição:");

        jLabelDecricao.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabelDecricao.setText("jLabel2");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setText("Quantidade de Parcelas:");

        jLabelQtdeParcelas.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabelQtdeParcelas.setText("jLabel3");

        btAlterar.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btAlterar.setText("Alterar");
        btAlterar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btAlterar.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btAlterarActionPerformed(evt);
            }
        });

        btRemover.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btRemover.setText("Remover");
        btRemover.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btRemover.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btRemoverActionPerformed(evt);
            }
        });

        btRetornar.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btRetornar.setText("Retornar");
        btRetornar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btRetornar.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btRetornarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabelQtdeParcelas))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(32, 32, 32)
                        .addComponent(jLabelDecricao))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btAlterar, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btRemover, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btRetornar, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(22, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabelDecricao))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabelQtdeParcelas))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btRemover, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btRetornar, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btAlterar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(25, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btAlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btAlterarActionPerformed
        this.setVisible(false);
        telaAlterar = new AlteraFormaPagtoTela(formaPagto, this);
        telaAlterar.setVisible(true);
    }//GEN-LAST:event_btAlterarActionPerformed

    private void btRemoverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btRemoverActionPerformed
        int resposta = JOptionPane.showConfirmDialog(null,"Deseja excluir esse Registro: "+jLabelDecricao.getText(),"CANCELAR",JOptionPane.YES_NO_OPTION);
        if(resposta == 0){
            removerBD();
            dispose();
            try {
                telaPrincipal.pesquisar();
            } catch (BDException ex) {
                Logger.getLogger(ConsultaFormaPagtoTela.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_btRemoverActionPerformed

    private void btRetornarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btRetornarActionPerformed
        dispose();
    }//GEN-LAST:event_btRetornarActionPerformed

    public void carregaLabels(){
        jLabelDecricao.setText(formaPagto.getDescricao());
        jLabelQtdeParcelas.setText(Integer.toString(formaPagto.getQtdeParcelas()));
        //jLabelCidade.setS;
        
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btAlterar;
    private javax.swing.JButton btRemover;
    private javax.swing.JButton btRetornar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabelDecricao;
    private javax.swing.JLabel jLabelQtdeParcelas;
    // End of variables declaration//GEN-END:variables
}
