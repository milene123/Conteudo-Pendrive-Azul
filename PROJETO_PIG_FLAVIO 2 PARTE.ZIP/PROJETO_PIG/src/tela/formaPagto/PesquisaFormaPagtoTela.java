/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tela.formaPagto;

import DAO.FormaPagtoDAO;
import Modelo.FormaPagto;
import Modelo.FormaPagtoTabelaModelo;
import excecao.BDException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowFocusListener;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JMenuItem;


public class PesquisaFormaPagtoTela extends javax.swing.JFrame {

    private FormaPagto formaPagto = new FormaPagto();
    public List<FormaPagto> formaPagtos = new ArrayList<FormaPagto>();//instanciar uma arraylist
    private CadastroFormaPagtoTela telaCadastro;
    private ConsultaFormaPagtoTela telaConsulta; 
    private FormaPagto formaPagtoSelecionada;
    public PesquisaFormaPagtoTela() throws BDException {
        initComponents();
        definirMenuFlutuante();
        pesquisar();
        addWindowFocusListener(new WindowFocusListener() {//Esse metodo atualiza a lista de cadastro quando terminar de realizar o cadastro

            
            @Override
            public void windowGainedFocus(WindowEvent e) {
                try {
                    pesquisar();
                } catch (BDException ex) {
                    Logger.getLogger(PesquisaFormaPagtoTela.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

            @Override
            public void windowLostFocus(WindowEvent e) {
                
            }
        });
    }
    
     private void definirMenuFlutuante(){
        
        tabelaFormaPagto.setSelectionMode(2); //Define apenas uma linha marcada
        
        JMenuItem itemConsultar = new JMenuItem("Consultar");
        JMenuItem itemAlterar = new JMenuItem("Alterar");
        JMenuItem itemExcluir = new JMenuItem("Excluir");
        
        itemConsultar.addActionListener(new ActionListener(){
            
            public void actionPerformed(ActionEvent e){
                abrirTelaConsultaFormaPagto();
            }
        });
        
        itemAlterar.addActionListener(new ActionListener() {
            

            @Override
            public void actionPerformed(ActionEvent e) {
                AlteraFormaPagtoTela alteraFormaPagto = new AlteraFormaPagtoTela(selecionarFormaPagto(), null);
                alteraFormaPagto.setVisible(true);

            }   
        });
        itemExcluir.addActionListener(new ActionListener() {
            

            @Override
            public void actionPerformed(ActionEvent e) {
                abrirTelaConsultaFormaPagto();
            }  
            
        });
        
        MenuContexto.add(itemConsultar);//Chamando os metodos que forem implementados em cima
        MenuContexto.add(itemAlterar);
        MenuContexto.add(itemExcluir);
    
    }
     public void abrirTelaConsultaFormaPagto(){
        telaConsulta = new ConsultaFormaPagtoTela(selecionarFormaPagto(), this, formaPagtos);
        telaConsulta.setVisible(true);
    }
    
    
    
    public void preencherFiltro() {
        formaPagto.setDescricao(campoPesquisaDescricao.getText());
    }
    private void pesquisarBD() throws BDException{ 
        FormaPagtoDAO dao = new FormaPagtoDAO();
        formaPagtos = dao.pesquisar(formaPagto);
    }
    private void preencherTabela(){
        tabelaFormaPagto.setModel(new FormaPagtoTabelaModelo(formaPagtos)); 
    }
    void pesquisar() throws BDException{
        preencherFiltro();
        pesquisarBD();
        preencherTabela();
        
    }
    
    
    FormaPagto selecionarFormaPagto(){
        formaPagtoSelecionada = formaPagtos.get(tabelaFormaPagto.getSelectedRow());
        return formaPagtoSelecionada;
    }
     
     
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents()
    {

        MenuContexto = new javax.swing.JPopupMenu();
        jLabel1 = new javax.swing.JLabel();
        campoPesquisaDescricao = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabelaFormaPagto = new javax.swing.JTable();
        btPesquisar = new javax.swing.JButton();
        btCadastrar = new javax.swing.JButton();
        btRetornar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Pesquisar Forma de Pagamento");

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setText("Descrição:");

        campoPesquisaDescricao.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        tabelaFormaPagto.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tabelaFormaPagto.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][]
            {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String []
            {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tabelaFormaPagto.setComponentPopupMenu(MenuContexto);
        tabelaFormaPagto.addMouseListener(new java.awt.event.MouseAdapter()
        {
            public void mouseReleased(java.awt.event.MouseEvent evt)
            {
                tabelaFormaPagtoMouseReleased(evt);
            }
        });
        jScrollPane1.setViewportView(tabelaFormaPagto);

        btPesquisar.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btPesquisar.setText("Pesquisar");
        btPesquisar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btPesquisar.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btPesquisarActionPerformed(evt);
            }
        });

        btCadastrar.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btCadastrar.setText("Cadastrar");
        btCadastrar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btCadastrar.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btCadastrarActionPerformed(evt);
            }
        });

        btRetornar.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btRetornar.setText("Retornar");
        btRetornar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btRetornar.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btRetornarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel1)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(btCadastrar, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btRetornar, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(campoPesquisaDescricao, javax.swing.GroupLayout.PREFERRED_SIZE, 375, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btPesquisar, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(21, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(campoPesquisaDescricao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btPesquisar, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btCadastrar, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btRetornar, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(23, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btPesquisarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btPesquisarActionPerformed
        try {
            pesquisar();
        } catch (BDException ex) {
            Logger.getLogger(PesquisaFormaPagtoTela.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btPesquisarActionPerformed

    private void btCadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btCadastrarActionPerformed
        telaCadastro = new CadastroFormaPagtoTela(formaPagtos, this);
        //CadastroPessoaTela cadastrar = new CadastroPessoaTela();
        telaCadastro.setVisible(true);
    }//GEN-LAST:event_btCadastrarActionPerformed

    private void selecionarLinhaTabela(java.awt.event.MouseEvent evt){
        tabelaFormaPagto.clearSelection();
        
        int linha = tabelaFormaPagto.rowAtPoint(evt.getPoint());
        
        tabelaFormaPagto.setRowSelectionInterval(linha, linha);
    }
    private void tabelaFormaPagtoMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabelaFormaPagtoMouseReleased
        selecionarLinhaTabela(evt);
        
        selecionarFormaPagto();
        
        if (evt.isPopupTrigger()){ //Botao direito do mouse
            MenuContexto.setVisible(true);
        }else{
            
            if(evt.getClickCount() > 1){ //Botao esquerdo do mouse
                abrirTelaConsultaFormaPagto();
            }
        
        }
    }//GEN-LAST:event_tabelaFormaPagtoMouseReleased

    private void btRetornarActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btRetornarActionPerformed
    {//GEN-HEADEREND:event_btRetornarActionPerformed
        dispose();
    }//GEN-LAST:event_btRetornarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PesquisaFormaPagtoTela.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PesquisaFormaPagtoTela.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PesquisaFormaPagtoTela.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PesquisaFormaPagtoTela.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new PesquisaFormaPagtoTela().setVisible(true);
                } catch (BDException ex) {
                    Logger.getLogger(PesquisaFormaPagtoTela.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPopupMenu MenuContexto;
    private javax.swing.JButton btCadastrar;
    private javax.swing.JButton btPesquisar;
    private javax.swing.JButton btRetornar;
    private javax.swing.JTextField campoPesquisaDescricao;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tabelaFormaPagto;
    // End of variables declaration//GEN-END:variables
}
