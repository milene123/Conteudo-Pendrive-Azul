/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import DAO.EstadoDAO;
import Modelo.Estado;
import excecao.BDException;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;
import net.sf.jasperreports.engine.JRException;

/**
 *
 * @author flavio
 */
public class EstadoTeste
{
    public static void main(String[] args) throws BDException, JRException, SQLException {
        pesquisarEstados();
    }
    
    
    
    static void deletarEstado() throws BDException{
        EstadoDAO estDao = new EstadoDAO();
        Estado e = new Estado();
        Scanner s = new Scanner(System.in);
        
        System.out.println("Digite o id do Estado a ser excluído:");
        e.setId(s.nextLong());
        
        estDao.deletar(e);
    }
    
    static void alterarEstado() throws BDException{
        EstadoDAO estDao = new EstadoDAO();
        Estado e = new Estado();
        Scanner s = new Scanner(System.in);
        
        System.out.println("Digite o ID do Estado a ser alterado: ");
        e.setId(s.nextLong());
        System.out.println("ID digitado: " + e.getId());
        
        s.nextLine();
        System.out.println("Digite o novo nome: ");
        e.setNome(s.nextLine());
        System.out.println("Nome digitado: " + e.getNome());
        
        estDao.alterar(e);
    }
    
    static List<Estado> pesquisarEstados() throws BDException{
        Estado estado = new Estado();
        EstadoDAO estDao = new EstadoDAO();
        Scanner s = new Scanner(System.in);
        
        System.out.println("Digite o nome do Estado a ser pesquisado:");
        estado.setNome(s.nextLine());
        System.out.println("Nome digitado: " + estado.getNome());
        
        List<Estado> estados = estDao.pesquisar(estado);
        
        for (Estado e: estados){
            System.out.println("ID: " + e.getId() + " - " + e.getNome());
        }
        
        return estados;
    }
    
    static void popularBaseDados() throws BDException{
        EstadoDAO estDao = new EstadoDAO();
        
        for (int i = 0; i < 5; i++){
            Estado e = cadastrarEstado();
            System.out.println("Nome do Estado: " + e.getNome());
            estDao.inserir(e);
        }
    }
    public static Estado cadastrarEstado() throws BDException{
        Estado estado = new Estado();
        EstadoDAO estDao = new EstadoDAO();
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Digite o nome do Estado");
        estado.setNome(scanner.nextLine());
        
        estDao.inserir(estado);
        
        return estado;
    }
    
    static void listaEstados(){
        
    }
}
