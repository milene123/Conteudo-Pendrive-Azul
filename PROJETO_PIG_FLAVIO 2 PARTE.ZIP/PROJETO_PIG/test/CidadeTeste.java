
import DAO.CidadeDAO;
import Modelo.Cidade;
import Modelo.Estado;
import excecao.BDException;
import java.util.List;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author flavio
 */
public class CidadeTeste
{
    public static void main (String[] args) throws BDException{
        pesquisar();
    }
    
    public static void cadastrar() throws BDException{
        Cidade c = new Cidade();
        Estado  e = new Estado();
        CidadeDAO dao = new CidadeDAO();
        Scanner s = new Scanner(System.in);
        
        System.out.println("Digite o nome da nova Cidade:");
        c.setNome(s.nextLine());
        
        System.out.println("Digite o id do Estado ao qual pertence esta cidade:");
        e.setId(s.nextLong());
        c.setEstado(e);
        
        dao.inserir(c);
    }
    
    public static void deletar () throws BDException{
        Cidade c = new Cidade();
        CidadeDAO dao = new CidadeDAO();
        Scanner s = new Scanner(System.in);
        
        System.out.println("Digite o ID da Cidade a ser excluída:");
        c.setId(s.nextLong());
        
        dao.deletar(c);
    }
    
    public static void alterar() throws BDException{
        Cidade c = new Cidade();
        CidadeDAO dao = new CidadeDAO();
        Scanner s = new Scanner(System.in);
        
        System.out.println("Digite o ID da Cidade a ser alterada:");
        c.setId(s.nextLong());
        
        s.nextLine();
        System.out.println("\nDigite o Novo nome da cidade:");
        c.setNome(s.nextLine());
        
        System.out.println("\nDigite o ID do novo estado da cidade:");
        c.setEstado(new Estado());
        c.getEstado().setId(s.nextLong());
        
        dao.alterar(c);
    }
    
    public static void consultar() throws BDException{
        Cidade c = new Cidade();
        CidadeDAO dao = new CidadeDAO();
        Scanner s = new Scanner(System.in);
        
        System.out.println("Digite o codigo da Cidade a ser consultada:");
        c.setId(s.nextLong());
        
        c = dao.consultar(c);
        
        System.out.println("\n\nDetalhes da Cidade: "
                + "\n > ID: ------- " + c.getId()
                + "\n > Nome: ----- " + c.getNome()
                + "\n > Estado: --- " + c.getEstado().getNome());
    }
    
    public static void pesquisar() throws BDException{
        Cidade c = new Cidade();
        List<Cidade> cidades;
        CidadeDAO dao = new CidadeDAO();
        Scanner s = new Scanner(System.in);
        
        System.out.println("Digite o nome da Cidade a ser pesquisada:");
        c.setNome(s.nextLine());
        
        cidades = dao.pesquisar(c);
        
        for (Cidade aux: cidades){
            System.out.println("\n\nDetalhes da Cidade: "
                + "\n > ID: ------- " + aux.getId()
                + "\n > Nome: ----- " + aux.getNome());
        }
    }
}
