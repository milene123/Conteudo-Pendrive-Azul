
import DAO.ClienteDAO;
import Modelo.Cidade;
import Modelo.Cliente;
import excecao.BDException;
import java.util.List;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
public class ClienteTeste
{
    public static void main (String[] args) throws BDException{
        pesquisar();
        consultar();
    }
    
    public static void cadastrar() throws BDException{
        Cliente c = new Cliente();
        ClienteDAO dao = new ClienteDAO();
        Scanner s = new Scanner(System.in);
        
        System.out.println("Digite o nome do novo Cliente:");
        c.setNome(s.nextLine());
        System.out.println("Digite o endereço do novo Cliente:");
        c.setEndereco(s.nextLine());
        System.out.println("Digite o telefone do novo Cliente:");
        c.setTelefone(s.nextLine());
        System.out.println("Digite o id da Cidade ao qual pertence este Cliente:");
        c.setCidade(new Cidade());
        c.getCidade().setId(s.nextLong());
        
        dao.inserir(c);
    }
    
    public static void deletar () throws BDException{
        Cliente c = new Cliente();
        ClienteDAO dao = new ClienteDAO();
        Scanner s = new Scanner(System.in);
        
        System.out.println("Digite o ID do Cliente a ser excluído:");
        c.setId(s.nextLong());
        
        dao.deletar(c);
    }
    
    public static void alterar() throws BDException{
        Cliente c = new Cliente();
        ClienteDAO dao = new ClienteDAO();
        Scanner s = new Scanner(System.in);
        
        System.out.println("Digite o ID do Cliente a ser alterado:");
        c.setId(s.nextLong());
        
        s.nextLine();
        System.out.println("\nDigite o nome do cliente:");
        c.setNome(s.nextLine());
        System.out.println("\nDigite o endereço:");
        c.setEndereco(s.nextLine());
        System.out.println("\nDigite o telefone:");
        c.setTelefone(s.nextLine());
        System.out.println("\nDigite o ID da nova cidade do cliente:");
        c.setCidade(new Cidade());
        c.getCidade().setId(s.nextLong());
        
        dao.alterar(c);
    }
    
    public static void consultar() throws BDException{
        Cliente c = new Cliente();
        ClienteDAO dao = new ClienteDAO();
        Scanner s = new Scanner(System.in);
        
        System.out.println("Digite o codigo do Cliente a ser consultado:");
        c.setId(s.nextLong());
        
        c = dao.consultar(c);
        
        System.out.println("\n\nDetalhes do Cliente: "
                + "\n > ID: ------- " + c.getId()
                + "\n > Nome: ----- " + c.getNome()
                + "\n > Endereco: - " + c.getEndereco()
                + "\n > Telefone: - " + c.getTelefone()
                + "\n > Cidade: --- " + c.getCidade().getNome()
                + "\n > Estado: --- " + c.getCidade().getEstado().getNome());
    }
    
    public static void pesquisar() throws BDException{
        Cliente c = new Cliente();
        List<Cliente> clientes;
        ClienteDAO dao = new ClienteDAO();
        Scanner s = new Scanner(System.in);
        
        System.out.println("Digite o nome do Cliente a ser pesquisado:");
        c.setNome(s.nextLine());
        System.out.println("Digite o telefone do Cliente a ser pesquisado:");
        c.setTelefone(s.nextLine());
        
        clientes = dao.pesquisar(c);
        
        for (Cliente aux: clientes){
            System.out.println("\nDetalhes do Cliente: "
                + "\n > ID: ------- " + aux.getId()
                + "\n > Nome: ----- " + aux.getNome()
                + "\n > Telefone: --- " + aux.getTelefone());
        }
    }
}
