
import DAO.VendaDAO;
import Modelo.Cliente;
import Modelo.FormaPagto;
import Modelo.Venda;
import excecao.BDException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
public class VendaTeste
{
    public static void main (String[] args) throws BDException, ParseException{
        deletar();
        deletar();
        deletar();
    }
    
    public static void cadastrar() throws BDException, ParseException{
        Venda v = new Venda();
        VendaDAO dao = new VendaDAO();
        Scanner s = new Scanner(System.in);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
        Cliente cli = new Cliente();
        FormaPagto fp = new FormaPagto();
        
        System.out.println("Digite a data da nova Venda:");
        String str = s.nextLine();
        v.setData(str);
        
        System.out.println("Digite o código do Cliente:");
        cli.setId(s.nextLong());
        System.out.println("Digite o código da Forma de Pagamento:");
        fp.setId(s.nextLong());
        v.setCliente(cli);
        v.setFormaPagto(fp);
        
        dao.inserir(v);
    }
    
    public static void deletar () throws BDException{
        Venda v = new Venda();
        VendaDAO dao = new VendaDAO();
        Scanner s = new Scanner(System.in);
        
        System.out.println("Digite o ID da Venda a ser excluída:");
        v.setId(s.nextLong());
        
        dao.deletar(v);
    }
    
    public static void alterar() throws BDException, ParseException{
        Venda v = new Venda();
        VendaDAO dao = new VendaDAO();
        Scanner s = new Scanner(System.in);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
        Cliente cli = new Cliente();
        FormaPagto fp = new FormaPagto();
        
        System.out.println("Digite o código da Venda a ser alterada:");
        v.setId(s.nextLong());
        
        s.nextLine();
        System.out.println("Digite a nova data Venda:");
        String str = s.nextLine();
        v.setData(sdf.parse(str));
        
        System.out.println("Digite o código do Cliente:");
        cli.setId(s.nextLong());
        System.out.println("Digite o código da Forma de Pagamento:");
        fp.setId(s.nextLong());
        
        v.setCliente(cli);
        v.setFormaPagto(fp);
        
        dao.alterar(v);
    }
    
    public static void consultar() throws BDException{
        Venda v = new Venda();
        VendaDAO dao = new VendaDAO();
        Scanner s = new Scanner(System.in);
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        
        System.out.println("Digite o codigo do Venda a ser consultado:");
        v.setId(s.nextLong());
        
        v = dao.consultar(v);
        
        System.out.println("\n\nDetalhes do Venda: "
                + "\n > ID: ----------------------- " + v.getId()
                + "\n > Data: --------------------- " + sdf.format(v.getData().getTime())
                + "\n > Cliente: ------------------ " + v.getCliente().getNome()
                + "\n > Telefone Cliente: --------- " + v.getCliente().getTelefone()
                + "\n > FormaPagamento: ----------- " + v.getFormaPagto().getDescricao()
                + "\n > Quantidade de Parcelas: --- " + v.getFormaPagto().getQtdeParcelas());
    }
    
    public static void pesquisar() throws BDException, ParseException{
        Venda v = new Venda();
        List<Venda> vendas;
        VendaDAO dao = new VendaDAO();
        Scanner s = new Scanner(System.in);
        Cliente c = new Cliente();
        SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/yyyy");
        SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy/MM/dd");
        
        System.out.println("Digite o ID da Venda a ser pesquisada:");
        try{
            v.setId(Long.parseLong(s.nextLine()));
        }catch(Exception e){
            /*Se houver erro, apenas deixa-se o ID da venda como nulo, pois isso será tratado no VendaDAO*/
        }
        
        System.out.println("Digite a data da Venda a ser pesquisada:");
        String str = s.nextLine();
        v.setData(str);   
        
        
        System.out.println("Digite o nome do Cliente a ser Pesquisado:");
        c.setNome(s.nextLine());
        v.setCliente(c);
        
        vendas = dao.pesquisar(v);
        
        for (Venda aux: vendas){
            System.out.println("\nDetalhes da Venda: "
                + "\n > ID: -------- " + aux.getId()
                + "\n > Data: ------ " + sdf1.format(aux.getData().getTime())
                + "\n > Cliente: --- " + aux.getCliente().getNome());
        }
    }
}
