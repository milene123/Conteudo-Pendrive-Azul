
import DAO.FormaPagtoDAO;
import Modelo.FormaPagto;
import excecao.BDException;
import java.util.List;
import java.util.Scanner;


public class FormaPagtoTeste
{
    public static void main (String[] args) throws BDException{
        consultar();
    }
    
    public static void cadastrar() throws BDException{
        FormaPagto fp = new FormaPagto();
        FormaPagtoDAO dao = new FormaPagtoDAO();
        Scanner s = new Scanner(System.in);
        
        System.out.println("Digite a descrição da nova Forma de Pagamento:");
        fp.setDescricao(s.nextLine());
        System.out.println("Digite a quantidade de parcelas:");
        fp.setQtdeParcelas(s.nextInt());
        
        dao.inserir(fp);
    }
    
    public static void deletar () throws BDException{
        FormaPagto fp = new FormaPagto();
        FormaPagtoDAO dao = new FormaPagtoDAO();
        Scanner s = new Scanner(System.in);
        
        System.out.println("Digite o ID da Forma de pagamento a ser excluída:");
        fp.setId(s.nextLong());
        
        dao.deletar(fp);
    }
    
    public static void alterar() throws BDException{
        FormaPagto fp = new FormaPagto();
        FormaPagtoDAO dao = new FormaPagtoDAO();
        Scanner s = new Scanner(System.in);
        
        System.out.println("Digite o ID do Forma de pagamento a ser alterada:");
        fp.setId(s.nextLong());
        
        s.nextLine();
        System.out.println("\nDigite a descrição da forma de pagamento:");
        fp.setDescricao(s.nextLine());
        System.out.println("\nDigite a quantidade de parcelas:");
        fp.setQtdeParcelas(s.nextInt());
        
        dao.alterar(fp);
    }
    
    public static void consultar() throws BDException{
        FormaPagto fp = new FormaPagto();
        FormaPagtoDAO dao = new FormaPagtoDAO();
        Scanner s = new Scanner(System.in);
        
        System.out.println("Digite o codigo do FormaPagto a ser consultado:");
        fp.setId(s.nextLong());
        
        fp = dao.consultar(fp);
        
        System.out.println("\n\nDetalhes do FormaPagto: "
                + "\n > ID: ------- " + fp.getId()
                + "\n > Descrição: ----- " + fp.getDescricao()
                + "\n > Qtde Parcelas -- " + fp.getQtdeParcelas());
    }
    
    public static void pesquisar() throws BDException{
        FormaPagto fp = new FormaPagto();
        List<FormaPagto> formaPagtos;
        FormaPagtoDAO dao = new FormaPagtoDAO();
        Scanner s = new Scanner(System.in);
        
        System.out.println("Digite a descrição do FormaPagto a ser pesquisado:");
        fp.setDescricao(s.nextLine());
        
        formaPagtos = dao.pesquisar(fp);
        
        for (FormaPagto aux: formaPagtos){
            System.out.println("\nDetalhes do FormaPagto: "
                + "\n > ID: ------- " + aux.getId()
                + "\n > Descrição: ----- " + aux.getDescricao());
        }
    }
}
