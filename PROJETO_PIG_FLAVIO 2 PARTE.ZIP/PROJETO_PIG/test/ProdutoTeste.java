
import DAO.ProdutoDAO;
import Modelo.Produto;
import excecao.BDException;
import java.util.List;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
public class ProdutoTeste
{
    public static void main (String[] args) throws BDException{
        pesquisar();
    }
    
    public static void cadastrar() throws BDException{
        Produto p = new Produto();
        ProdutoDAO dao = new ProdutoDAO();
        Scanner s = new Scanner(System.in);
        
        System.out.println("Digite a descrição do novo Produto:");
        p.setDescricao(s.nextLine());
        
        dao.inserir(p);
    }
    
    public static void deletar () throws BDException{
        Produto p = new Produto();
        ProdutoDAO dao = new ProdutoDAO();
        Scanner s = new Scanner(System.in);
        
        System.out.println("Digite o ID do Produto a ser excluído:");
        p.setId(s.nextLong());
        
        dao.deletar(p);
    }
    
    public static void alterar() throws BDException{
        Produto p = new Produto();
        ProdutoDAO dao = new ProdutoDAO();
        Scanner s = new Scanner(System.in);
        
        System.out.println("Digite o ID do Produto a ser alterado:");
        p.setId(s.nextLong());
        
        s.nextLine();
        System.out.println("\nDigite a descrição do produto:");
        p.setDescricao(s.nextLine());
        
        dao.alterar(p);
    }
    
    public static void consultar() throws BDException{
        Produto p = new Produto();
        ProdutoDAO dao = new ProdutoDAO();
        Scanner s = new Scanner(System.in);
        
        System.out.println("Digite o codigo do Produto a ser consultado:");
        p.setId(s.nextLong());
        
        p = dao.consultar(p);
        
        System.out.println("\n\nDetalhes do Produto: "
                + "\n > ID: ------- " + p.getId()
                + "\n > Nome: ----- " + p.getDescricao());
    }
    
    public static void pesquisar() throws BDException{
        Produto p = new Produto();
        List<Produto> produtos;
        ProdutoDAO dao = new ProdutoDAO();
        Scanner s = new Scanner(System.in);
        
        System.out.println("Digite a descrição do Produto a ser pesquisado:");
        p.setDescricao(s.nextLine());
        
        produtos = dao.pesquisar(p);
        
        for (Produto aux: produtos){
            System.out.println("\nDetalhes do Produto: "
                + "\n > ID: ------- " + aux.getId()
                + "\n > Nome: ----- " + aux.getDescricao());
        }
    }
}
