
import DAO.ItemVendaDAO;
import Modelo.Cidade;
import Modelo.ItemVenda;
import Modelo.Produto;
import Modelo.Venda;
import excecao.BDException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
public class ItemVendaTeste
{
    public static void main (String[] args) throws BDException{
        pesquisar();
        pesquisar();
    }
    
    public static void cadastrar() throws BDException{
        ItemVenda itv = new ItemVenda();
        ItemVendaDAO dao = new ItemVendaDAO();
        Scanner s = new Scanner(System.in);
        Venda v = new Venda();
        Produto p = new Produto();
        
        System.out.println(" << ----- CADASTRO ----- >>");
        System.out.println("Digite o código da Venda:");
        v.setId(s.nextLong());
        itv.setVenda(v);
        System.out.println("Digite o código do Produto:");
        p.setId(s.nextLong());
        System.out.println("Digite a quantidade do Item:");
        itv.setQtde(s.nextInt());
        
        itv.setProduto(p);
        
        dao.inserir(itv);
    }
    
    public static void deletar () throws BDException{
        ItemVenda itv =new ItemVenda();
        ItemVendaDAO dao = new ItemVendaDAO();
        Scanner s = new Scanner(System.in);
        
        System.out.println(" << ----- DELETAR ----- >>");
        System.out.println("Digite o ID do Item a ser excluído:");
        itv.setId(s.nextLong());
        
        dao.deletar(itv);
    }
    
    public static void alterar() throws BDException{
        ItemVenda itv = new ItemVenda();
        ItemVendaDAO dao = new ItemVendaDAO();
        Scanner s = new Scanner(System.in);
        Venda v = new Venda();
        Produto p = new Produto();
        
        System.out.println(" << ----- ALTERAR ----- >>");
        System.out.println("Digite o ID do Item a ser alterado:");
        itv.setId(s.nextLong());
        
        System.out.println("Digite a quantidade do Item:");
        itv.setQtde(s.nextInt());
        System.out.println("Digite o código da Venda:");
        v.setId(s.nextLong());
        itv.setVenda(v);
        System.out.println("Digite o código do Produto:");
        p.setId(s.nextLong());
        itv.setProduto(p);
        
        dao.alterar(itv);
    }
    
    public static void consultar() throws BDException{
        ItemVenda itv = new ItemVenda();
        ItemVendaDAO dao = new ItemVendaDAO();
        Scanner s = new Scanner(System.in);
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        
        System.out.println("Digite o codigo do ItemVenda a ser consultado:");
        itv.setId(s.nextLong());
        
        itv = dao.consultar(itv);
        
        System.out.println("\n\nDetalhes do ItemVenda: "
                + "\n > ID: ------- " + itv.getId()
                + "\n > Quantidade: ----- " + itv.getQtde()
                + "\n > ID Venda: - " + itv.getVenda().getId()
                + "\n > Data Venda: - " + sdf.format(itv.getVenda().getData().getTime())
                + "\n > Produto: --- " + itv.getProduto().getDescricao());
    }
    
    public static void pesquisar() throws BDException{
        ItemVenda itv =new ItemVenda();
        List<ItemVenda> itemVendas;
        ItemVendaDAO dao = new ItemVendaDAO();
        Scanner s = new Scanner(System.in);
        Venda v = new Venda();
        Produto p = new Produto();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        
        
        System.out.println("Digite o ID da Venda do Item a ser pesquisado:");
        try{
            v.setId(Long.parseLong(s.nextLine()));
        }catch(Exception e){
            /*Se houver erro, apenas deixa-se o ID da venda como nulo, pois isso será tratado no VendaDAO*/
        }
        itv.setVenda(v);
        
        System.out.println("Digite a Descrição do Produto do Item a ser pesquisado:");
        p.setDescricao(s.nextLine());
        itv.setProduto(p);
        
        itemVendas = dao.pesquisar(itv);
        
        for (ItemVenda aux: itemVendas){
            System.out.println("\nDetalhes do Item: "
                + "\n > ID: ------- " + aux.getId()
                + "\n > Data Venda: ----- " + sdf.format(aux.getVenda().getData().getTime())
                + "\n > Produto: --- " + aux.getProduto().getDescricao());
        }
    }
}
